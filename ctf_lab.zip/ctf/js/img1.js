<div id="x"></div>

<script>
var img = document.createElement("img");
 
img.src = "m1.jpeg";
var src = document.getElementById("x");
 
src.appendChild(img);
</script>